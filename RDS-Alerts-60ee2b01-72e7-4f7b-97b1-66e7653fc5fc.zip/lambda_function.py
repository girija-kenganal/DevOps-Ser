import json
import logging
import os
import boto3
import datetime

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    print(event)
    
    Source = event['source']
    Account = event['account']
    EventTime = event['time']
    Region = event['region']
    print(Source)
    print(Account)
    print(EventTime)
    print(Region)
    #PrincipalId = event['detail']['userIdentity']['principalId']
    #EventSource = event['detail']['eventSource']
    #EventName = event['detail']['eventName']
    DBInstanceIdentifier = event['detail']['SourceIdentifier']
    AlertReason = event['detail']['Message'] 
    #print(PrincipalId)
    print(DBInstanceIdentifier)
    #print(EventSource) 
    #print(EventName) 
    print(AlertReason)
    
    if AlertReason == 'DB instance stopped' or AlertReason == 'DB instance restarted' or AlertReason == 'DB instance terminated' or AlertReason == 'DB instance created':
        Subject = 'Production RDS alert'
        SnsMessage = Subject+ ' and DBInstanceIdentifier = ' +DBInstanceIdentifier+ '\n\rAlertReason = ' +AlertReason+ '\nEventTime = ' +EventTime+ '\n\rAccount = ' +Account+ '\t and Region = ' +Region    
        
        #calling SNS message publish function to publish notification to email protocol 
        publishMessageToSNSTopic(SnsMessage,AlertReason,EventTime)
    else:
        Subject = 'Production RDS alert'
        SnsMessage = Subject+ ' and DBInstanceIdentifier = ' +DBInstanceIdentifier+ '\n\rAlertReason = ' +AlertReason+ '\nEventTime = ' +EventTime+ '\n\rAccount = ' +Account+ '\t and Region = ' +Region   
        
        #calling SNS message publish function to publish notification to email protocol
        #publishMessageToEmailSNSTopic(SnsMessage,AlertReason,EventTime)
        
    
def publishMessageToSNSTopic(SnsMessage,AlertReason,EventTime):
    sns = boto3.client('sns')
    response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:512169772597:SKYDRM-DEVSECOPS',
        Subject='Production Skydrm RDS alert and EventTime: ' +AlertReason+ '-' +EventTime,
        Message= SnsMessage
    )
    print(response) 
    
def publishMessageToEmailSNSTopic(SnsMessage,AlertReason,EventTime):
    sns = boto3.client('sns')
    response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:512169772597:EmailDevSecOps',
        Subject='Production Skydrm RDS alert: ' +AlertReason+ '-' +EventTime,
        Message= SnsMessage
    )
    print(response)    