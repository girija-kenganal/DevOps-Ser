import json
import logging
import boto3

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

def lambda_handler(event, context):
    print(event)
    Subject = event['detail-type']
    EventSource = event['source']
    Service = event['detail']['service']
    Time = event['time']
    EventTypeCode = event['detail']['eventTypeCode']
    EventTypeCategory = event['detail']['eventTypeCategory'] 
    EventStartTime = event['detail']['startTime']
    EventEndTime = event['detail']['endTime'] 
    Language = event['detail']['eventDescription'][0]['language']
    LatestDescription = event['detail']['eventDescription'][0]['latestDescription']
    print(Subject)
    print(Service)
    print(EventTypeCategory)
    print(EventStartTime)
    print(EventEndTime)
    print(Language)
    print(LatestDescription)
    print(EventTypeCode)
    print(Time)
    Subject = 'ServiceOps AWS Health Dashboard alerts'
    SnsMessage = Subject+ '\nService = ' +Service+ '\nEventCategory = ' +EventTypeCategory+ '\n\rEventStartTime = ' +EventStartTime+ '\t and EventEndTime = ' +EventEndTime+ '\nLatestDescription = ' +LatestDescription+ '\t and Language = ' +Language    
   
    #calling SNS message publish function to publish notification to email protocol 
    publishMessageToSNSTopic(SnsMessage,EventTypeCode,Time)
    
def publishMessageToSNSTopic(SnsMessage,EventTypeCode,Time):
    sns = boto3.client('sns')
    Result = 'ServiceOps CloudAZ AWSHealthDashboard: '+EventTypeCode+ '-'+Time
    response = sns.publish(
        TopicArn='arn:aws:sns:us-west-2:948173514100:testTopic',
        Subject= Result,
        Message= SnsMessage
    )
    print(response)
    
    
    
    
    


