import json,boto3
import time
import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def lambda_handler(event, context):
    print(event)
    dynamodb = boto3.resource('dynamodb','us-west-2')
    table = dynamodb.Table('askquestion')
    
    #Check If customer record exists already
    print(event["Records"][0]['eventName'])
    
    if event["Records"][0]['eventName']=='INSERT':
        company=event["Records"][0]['dynamodb']['NewImage']['company']['S']
        name=event["Records"][0]['dynamodb']['NewImage']['name']['S']
        email=event["Records"][0]['dynamodb']['NewImage']['email']['S']
        phone=event["Records"][0]['dynamodb']['NewImage']['phone']['S']
        sourceType=event["Records"][0]['dynamodb']['NewImage']['sourceType']['S']
        message=event["Records"][0]['dynamodb']['NewImage']['message']['S']
        registerDate=event["Records"][0]['dynamodb']['NewImage']['registerDate']['S']
        qid=event["Records"][0]['dynamodb']['NewImage']['qid']['N']
    
        
        toEmail="David.Lim@nextlabs.com, info@nextlabs.com"
        
        #toEmail="gamaresh@nextlabs.com"
        fromEmail ="saas@nextlabs.com"
        
        
    
        # Create message container - the correct MIME type is multipart/alternative.
        msg = MIMEMultipart('alternative')
        msg['Subject'] = sourceType + ": Ask Question Form Data"
        msg['From'] = fromEmail
        msg['To'] = toEmail
        
        # Create the body of the message (a plain-text and an HTML version).
       
        html = """
            <html>
                <head>
              <style type="text/css">
                .askForm {
                    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                }
    
                .askForm td, .askForm th {
                    border: 1px solid #ddd;
                    padding: 8px;
                }
    
                .askForm tr:nth-child(even){background-color: #f2f2f2;}
    
                .askForm tr:hover {background-color: #ddd;}
    
                .askForm th {
                    padding-top: 12px;
                    padding-bottom: 12px;
                    text-align: left;
                    background-color: #f16a25;
                    color: white;
                }
            </style>
            </head>
            <body>
            
            <table class='askForm'>
            """
            
        
    
        #print(datetime.datetime.strptime(dateString[0], "%Y-%m-%d").strftime("%Y-%m-%d"))
        
        dateString=registerDate.split("T")
        properDateFormat=dateString[0]
        
        html=html + '<tr>'
        html=html + '<td>Date Received</td>'
        html=html + '<td>' + properDateFormat + '</td>'
        html=html + '</tr>'
    
        html=html + '<tr>'
        html=html + '<td>Product</td>'
        html=html + '<td>' + sourceType + '</td>'
        html=html + '</tr>'
    
        html=html + '<tr>'
        html=html + '<td>Name</td>'
        html=html + '<td>' + name + '</td>'
        html=html + '</tr>'
        
        html=html + '<tr>'
        html=html + '<td>Email</td>'
        html=html + '<td>' + email + '</td>'
        html=html + '</tr>'
        
        html=html + '<tr>'
        html=html + '<td>Company</td>'
        html=html + '<td>' + company + '</td>'
        html=html + '</tr>'
    
        html=html + '<tr>'
        html=html + '<td>Phone</td>'
        html=html + '<td>' + phone + '</td>'
        html=html + '</tr>'
    
        html=html + '<tr>'
        html=html + '<td>Message</td>'
        html=html + '<td>' + message + '</td>'
        html=html + '</tr>'
    
        html=html + """
            </body>
          </html>
        """
        
        part = MIMEText(html, 'html')
        try:
            msg.attach(part)
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            
            if sourceType == 'cloudaz':
                server.login("admin@cloudaz.com", "sgjunjhxnqisfmwr")
            else:
                server.login("admin@skydrm.com", "tgfslcylugtlgtjk")
                
            
            
            server.sendmail(fromEmail, toEmail.split(","), msg.as_string())
            
            server.quit()
            print("email has been sent successfully")
            	
            
            if sourceType == 'cloudaz':
                # Invoke SNS topic -> arn:aws:sns:us-west-2:948173514100:CloudAz-Notify-Support
                publishMessageToCloudAzSNSTopic(sourceType,name,email,company,phone,message)
            else:    
                # Invoke SNS topic -> arn:aws:sns:us-west-2:948173514100:SkyDRM-Notify-Support
                publishMessageToSkyDRMSNSTopic(sourceType,name,email,company,phone,message)
    
        except smtplib.SMTPException as e:
            print(str(e))
       
            return { 
                    "statusCode": 500,
                    "body": json.dumps("error"),
                    "isBase64Encoded": "false",
                    "headers": {
                            "Access-Control-Allow-Origin" : "*", 
                            "Access-Control-Allow-Credentials" : "true"
                     }
            
            }
def publishMessageToCloudAzSNSTopic(sourceType,name,email,company,phone,message):
                sns = boto3.client('sns')
                response = sns.publish(
                    TopicArn='arn:aws:sns:us-west-2:948173514100:CloudAz-Notify-Support',
                    Subject='CloudAz: Questions and Answers',
                    Message='CloudAZ\n\rProduct = ' +sourceType+ '\nName = ' +name+ '\nEmail = ' +email+ '\nCompany = ' +company+ '\nPhone = ' +phone+ '\nMesssage = '+message    
                )
                #print(response)
                
def publishMessageToSkyDRMSNSTopic(sourceType,name,email,company,phone,message):
                sns = boto3.client('sns')
                response = sns.publish(
                    TopicArn='arn:aws:sns:us-west-2:948173514100:SkyDRM-Notify-Support',
                    Subject='SkyDRM: Questions and Answers',
                    Message='SkyDRM\n\rProduct = ' +sourceType+ '\nName = ' +name+ '\nEmail = ' +email+ '\nCompany = ' +company+ '\nPhone = ' +phone+ '\nMesssage = '+message    
                )     
