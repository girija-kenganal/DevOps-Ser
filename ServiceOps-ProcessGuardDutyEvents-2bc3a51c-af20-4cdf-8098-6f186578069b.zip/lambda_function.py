import json,boto3

def lambda_handler(event, context):
    
    accountId=event[0]["accountId"]
    region=event[0]["region"]
    createdAt=event[0]["createdAt"]
    detectorId=event[0]['service']['detectorId']
    findingType=event[0]["type"]
    title=event[0]["title"]
    description=event[0]["description"]
    severity=event[0]["severity"]
    serviceName=event[0]['service']['serviceName']
    resourceType=event[0]['resource']['resourceType']
    actionType=event[0]["service"]["action"]["actionType"]
    resourceRole=event[0]['service']["resourceRole"]
    #print(resourceRole)
    #print(findingType)
    #print(serviceName)
    print(severity)
    severitylevel='Low'
    
    if severity >= 7 and severity <= 8.9:    
        severitylevel='High'
    elif severity >= 4 and severity <= 6.9:
        severitylevel='Medium'
    elif severity >= 0.1 and severity <= 3.9:
        severitylevel='Low'
    
    #print(severitylevel)   
    if severitylevel=='High' or severitylevel=='Medium':
        
        # Type of activity that triggered the finding
        print(severitylevel)
        print(accountId)
        print(region)
        print(createdAt)
        print(detectorId)
        print(findingType)
        print(resourceType)
        print(actionType)
        #print(instanceId)
        if resourceType == 'Instance':
            instanceId=event[0]["resource"]["instanceDetails"]["instanceId"]
            instanceState=event[0]["resource"]["instanceDetails"]["instanceState"]
            networkInterfaces=event[0]["resource"]["instanceDetails"]["networkInterfaces"]
            #publicIp=event[0]["resource"]["instanceDetails"]["networkInterfaces"][0]["publicIp"]
            print(instanceId)
            #print(instanceState)
            #print(networkInterfaces)
            #print(publicIp)
        elif resourceType == 'AccessKey': 
            accessKeyId=event[0]["resource"]["accessKeyDetails"]["accessKeyId"]
            principalId=event[0]["resource"]["accessKeyDetails"]["principalId"]
            userType=event[0]["resource"]["accessKeyDetails"]["userType"]
            userName=event[0]["resource"]["accessKeyDetails"]["userName"]
            print(accessKeyId)
            print(principalId)
            print(userType)
            print(userName)
            
        if actionType == 'AWS_API_CALL':
            api=event[0]["service"]["action"]["awsApiCallAction"]["api"]
            callerType=event[0]["service"]["action"]["awsApiCallAction"]["callerType"]
            remoteIpDetails=event[0]["service"]["action"]["awsApiCallAction"]["remoteIpDetails"]["ipAddressV4"]
            organization=event[0]["service"]["action"]["awsApiCallAction"]["remoteIpDetails"]["organization"]["org"]
            country=event[0]["service"]["action"]["awsApiCallAction"]["remoteIpDetails"]["country"]["countryName"]
            print(api)
            print(callerType)
            print(organization)
            print(country)
            #Message='Finding type\n' +findingType+ '\n\rTitle = ' +title+ '\nSeverity = ' +severitylevel+ '\nAccountId = ' +accountId+ '\nRegion = ' +region+ '\nDescription = ' +description+ '\nResourceType = ' +resourceType+ '\nActionType = ' +actionType+ '\nApi = ' +api+ '\nCallerType = ' +callerType+ '\nOrganization = ' +organization+ '\nCountry = ' +country+ '\nAccessKeyId = ' +accessKeyId+ '\nPrincipalId = ' +principalId+ '\nUserType = ' +userType+ '\nUserName = ' +userName
            
            Message='GuardDuty Findings\n' +findingType+ '- Severity : ' +severitylevel+ '\n\r' +title+ '\nDescription : ' +description+ '\nAccountId : ' +accountId+ '\tRegion : ' +region+  '\nResourceType : ' +resourceType+ '\tActionType : ' +actionType+ '\nSensitiveApiCall = ' +api+ '\nOrganization = ' +organization+ '\nCountry = ' +country+ '\nRemoteIpDetails : ' +remoteIpDetails+ '\nAccessKeyId = ' +accessKeyId+ '\nPrincipalId = ' +principalId+ '\nUserType = ' +userType+ '\nUserName = ' +userName
            publishMessageToSNSTopic(Message,findingType,severitylevel,createdAt)
            
        elif actionType == 'PORT_PROBE':
            localPortDetails=event[0]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["localPortDetails"]["port"]
            portName=event[0]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["localPortDetails"]["portName"]
            countryName=event[0]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["remoteIpDetails"]["country"]["countryName"]
            cityName=event[0]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["remoteIpDetails"]["city"]["cityName"]
            organization=event[0]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["remoteIpDetails"]["organization"]["org"]
            remoteIpDetails=event[0]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["remoteIpDetails"]["ipAddressV4"]
            print(localPortDetails)
            print(portName)
            print(countryName)
            print(organization)
            print(remoteIpDetails)
            Message='GuardDuty Findings\n' +findingType+ '- Severity : ' +severitylevel+ '\n\rTitle = ' +title+ '\nDescription = ' +description+ '\nAccountId = ' +accountId+ '\tRegion = ' +region+ '\nResourceType = ' +resourceType+ '\tActionType = ' +actionType+ '\nLocalPortDetails = ' +str(localPortDetails)+ '\nPortName = ' +portName+ '\nCountryName = ' +countryName+ '\nOrganization = ' +organization+ '\nRemoteIpDetails = ' +remoteIpDetails     
            publishMessageToSNSTopic(Message,findingType,severitylevel,createdAt)
            
        elif actionType == 'DNS_REQUEST':
            domain=event[0]["service"]["action"]["dnsRequestAction"]["domain"]
            protocol=event[0]["service"]["action"]["dnsRequestAction"]["protocol"]
            print(domain)
            print(protocol)
            Message='GuardDuty Findings\n' +findingType+ '- Severity : ' +severitylevel+ '\n\rTitle = ' +title+ '\nDescription = ' +description+ '\nAccountId = ' +accountId+ '\tRegion = ' +region+  '\nResourceType = ' +resourceType+ '\tActionType = ' +actionType+ '\nDomain = ' +domain+ '\nProtocol = ' +protocol 
            publishMessageToSNSTopic(Message,findingType,severitylevel,createdAt)
            
        elif actionType == 'NETWORK_CONNECTION':
            actionType =event[0]["service"]["action"]["actionType"]
            connectionDirection=event[0]["service"]["action"]["networkConnectionAction"]["connectionDirection"]
            ipAddressV4=event[0]["service"]["action"]["networkConnectionAction"]["remoteIpDetails"]["ipAddressV4"]
            organization=event[0]["service"]["action"]["networkConnectionAction"]["remoteIpDetails"]["organization"]["org"]
            country=event[0]["service"]["action"]["networkConnectionAction"]["remoteIpDetails"]["country"]["countryName"]
            city=event[0]["service"]["action"]["networkConnectionAction"]["remoteIpDetails"]["city"]["cityName"]
            remotePortDetails=event[0]["service"]["action"]["networkConnectionAction"]["remotePortDetails"]["port"]
            localPortDetails=event[0]["service"]["action"]["networkConnectionAction"]["localPortDetails"]["port"]
            protocol=event[0]["service"]["action"]["networkConnectionAction"]["protocol"]
            #print(actionType)
            print(connectionDirection)
            print(organization)
            print(ipAddressV4) 
            print(country)
            print(city)
            print(remotePortDetails)
            print(localPortDetails)
            print(protocol)
            Message='\GuardDuty Findings\n' +findingType+ '- Severity : ' +severitylevel+ '\n\rTitle = ' +title+  '\nDescription = ' +description+ '\nAccountId = ' +accountId+ '\tRegion = ' +region+  '\nResourceType = ' +resourceType+ '\tActionType = ' +actionType+ '\nConnectionDirection = ' +connectionDirection+ '\nOrganization = ' +organization+ '\nRemoteIpAddressV4 = ' +ipAddressV4+ '\nCountry = ' +country+ '\nCity = ' +city+ '\nRemotePortDetails = ' +str(remotePortDetails)+ '\nLocalPortDetails = ' +str(localPortDetails)+ '\nProtocol = ' +protocol 
            publishMessageToSNSTopic(Message,findingType,severitylevel,createdAt)

def publishMessageToSNSTopic(Message,findingType,severitylevel,createdAt):
    sns = boto3.client('sns')
    Result='ServiceOps CloudAZ Guarduty: ' +findingType+ '-' +severitylevel+ '-'+createdAt
    response = sns.publish(
        TopicArn='arn:aws:sns:us-west-2:948173514100:testTopic',
        Subject= Result,
        Message= Message
    )
    print(response)
     

 
          
        

