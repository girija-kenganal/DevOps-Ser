import json
import logging
import os
import boto3
import datetime

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    print(event)
    AlertName = event['detail-type']
    print(AlertName)
    EventTime = event['detail']['updatedAt']
    print(EventTime)
    ClusterARN = event['detail']['clusterArn']
    ContainerInstanceARN = event['detail']['containerInstanceArn']
    print(ClusterARN)
    print(ContainerInstanceARN)
    #RemainingInstanceCPU = event['detail']['remainingResources'][0]['integerValue']
    #RemainingInstanceMemory = event['detail']['remainingResources'][1]['integerValue']
    #print(RemainingInstanceCPU)
    #print(RemainingInstanceMemory)
    Account = event['account']
    Region = event['region']
    
    if AlertName == 'ECS Container Instance State Change':
        if ClusterARN == 'arn:aws:ecs:us-east-1:512169772597:cluster/WWW-SKYDRM-COM':
            RunningTasksCount = event['detail']['runningTasksCount']
            print(RunningTasksCount)
            Status = event['detail']['status']
            print(Status)
            if RunningTasksCount != 6: 
                Subject = 'Production SkyDRM ECS alert'
                SnsMessage = Subject+ '\n AlertName = ' +AlertName+ '\n\rEventTime = ' +EventTime+ '\nClusterARN = ' +ClusterARN+ '\n\rContainerInstanceARN' +ContainerInstanceARN+ '\n\rAccount = ' +Account+ '\t and Region = ' +Region    
                
                #calling SNS message publish function to publish notification to email protocol 
                publishMessageToSNSTopic(SnsMessage,AlertName,EventTime)
        elif ClusterARN == 'arn:aws:ecs:us-east-1:512169772597:cluster/WEIR-SKYDRM-COM':
            RunningTasksCount = event['detail']['runningTasksCount']
            print(RunningTasksCount)
            Status = event['detail']['status']
            print(Status)
            if RunningTasksCount != 5: 
                Subject = 'Production SkyDRM ECS alert'
                SnsMessage = Subject+ '\n AlertName = ' +AlertName+ '\n\rEventTime = ' +EventTime+ '\nClusterARN = ' +ClusterARN+ '\n\rContainerInstanceARN' +ContainerInstanceARN+ '\n\rAccount = ' +Account+ '\t and Region = ' +Region    
                
                #calling SNS message publish function to publish notification to email protocol 
                publishMessageToSNSTopic(SnsMessage,AlertName,EventTime)             
        else:
            print("No ECS Container Instance State Change e ")
    if AlertName == 'ECS Task State Change':
        DesiredStatus = event['detail']['desiredStatus']
        print(DesiredStatus)
        LastStatus = event['detail']['lastStatus']
        print(LastStatus)
        TaskName = event['detail']['containers'][0]['name']
        print(TaskName)
        
        if DesiredStatus != 'RUNNING':
            Subject = 'Production SkyDRM ECS alert'
            SnsMessage = Subject+ '\n AlertName = ' +AlertName+ '\n\rEventTime = ' +EventTime+ '\nClusterARN = ' +ClusterARN+ '\n\rContainerInstanceARN' +ContainerInstanceARN+ '\n\rAccount = ' +Account+ '\t and Region = ' +Region+ '\n\rTaskName = ' +TaskName+ '\n\rDesiredStatus = ' +DesiredStatus+ '\t and LastStatus = ' +LastStatus 
            
            #calling SNS message publish function to publish notification to email protocol 
            publishMessageToSNSTopic(SnsMessage,AlertName,EventTime)
    
def publishMessageToSNSTopic(SnsMessage,AlertName,EventTime):
    sns = boto3.client('sns')
    response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:512169772597:SKYDRM-DEVSECOPS',
        Subject='Production SkyDRM-ECS alert: ' +AlertName+ '-' +EventTime,
        Message= SnsMessage
    )
    print(response)     
    
    
    
    
    
    
    
    
    
   
    
