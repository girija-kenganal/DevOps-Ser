import boto3
import pprint
import os

#Build=""
region = "us-east-1"
ecs = boto3.client('ecs')

def lambda_handler(event, context):
    taskdefinition_response_approval = ecs.register_task_definition(
        family='approval-WEIR-SKYDRM-COM',
        containerDefinitions=[
            {
            "portMappings": [
                {
                "hostPort": 0,
                "protocol": "tcp",
                "containerPort": 5000
                }
            ],
            "environment": [
                {
                    "name": "PROD_APPROVER_URL",
                    "value": "https://admin.weir.skydrm.com/approver.html"
                },
                {
                    "name": "PORD_AWS_ACCESS_KEY_ID",
                    "value": "AKIAYNYEBS7YILTYJGUH"
                },
                {
                    "name": "PROD_AWS_REGION",
                    "value": "us-east-1"
                },
                {
                    "name": "PROD_AWS_SECRET_ACCESS_KEY",
                    "value": "mtT9zsP7L3PeGkkzm92BT7nVAeYl9IsZ6etmMnF4"
                },
                {
                    "name": "PROD_EMAIL_API_KEY",
                    "value": "iqrgPJeEpOa9csBRV9clc6HQz3PLLnL827tQgOuJ"
                },
                {
                    "name": "PROD_EMAIL_API_URL",
                    "value": "https://cd3leiihvi.execute-api.us-east-1.amazonaws.com/Prod/sod-email"
                },
                {
                    "name": "PROD_SKYDRM_API_URL",
                    "value": "https://weir.skydrm.com"
                },
                {
                    "name": "PROD_SUPPORT_EMAIL",
                    "value": "IT Support"
                },
                {
                    "name": "PROD_SUPPORT_NAME",
                    "value": "IT Support"
                },
                {
                    "name": "PROD_TENANT",
                    "value": "weir.skydrm.com"
                },
            ],
            "memoryReservation": 300,
            "image": "512169772597.dkr.ecr.us-east-1.amazonaws.com/skydrm-approval:latest",
            "name": "approval"
            }
        ],
        requiresCompatibilities= [
            "EC2"
        ],
        networkMode= "bridge"
    )
    #print taskDefinition revision
    print(taskdefinition_response_approval['taskDefinition']['revision'])
    #Update service
    taskDefinitionRev_approval = taskdefinition_response_approval['taskDefinition']['family'] + ':' + str(taskdefinition_response_approval['taskDefinition']['revision'])
    
    service_response_approval = ecs.update_service(
        cluster='WEIR-SKYDRM-COM',
        service='approval-WEIR-SKYDRM-COM',
        desiredCount=1,
        forceNewDeployment=True,
        taskDefinition=taskDefinitionRev_approval,
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    #print "service updated"
    print(service_response_approval)
    
