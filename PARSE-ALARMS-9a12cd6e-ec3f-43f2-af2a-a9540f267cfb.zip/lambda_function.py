import json
import logging
import os
import boto3
import datetime

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    print(event)
    
    #Message is of type string. You need to use json.loads(message) to convert it to a dictionary before accessing its fields
    Message = json.loads(event['Records'][0]['Sns']['Message'])
    print(Message)
    Subject = event['Records'][0]['Sns']['Subject']
   
    #pulling out specific information of cloudwatch alarm from event    
    AlarmName = Message['AlarmName']
    NewStateReason = Message['NewStateReason']
    StateChangeTime = Message['StateChangeTime']
    AlarmDescription =  Message['AlarmDescription']
    OldStateValue = Message['OldStateValue']
    NewStateValue = Message['NewStateValue']
    MetricName = Message ['Trigger']['MetricName']
    ComparisonOperator = Message ['Trigger']['ComparisonOperator']
    Threshold = Message ['Trigger']['Threshold']
    EvaluationPeriods = Message ['Trigger']['EvaluationPeriods']
    Period = Message ['Trigger']['Period']
    print(MetricName)
    Trigger = MetricName+ ' >= ' +str(Threshold)+' for '+str(EvaluationPeriods)+' datapoints within '+str(Period)+' seconds' 
    print(Trigger)
    print(Subject)
    print(AlarmName)
    AccountId = Message['AWSAccountId']
    Region =  Message['Region']
    
    SnsMessage = Subject+ '\n\rAlarm Reason = ' +NewStateReason+ '\nState Change Time = ' +StateChangeTime+ '\nAlarm Description = ' +str(AlarmDescription)+ '\nTrigger = ' +Trigger+ '\nOld Status = ' +OldStateValue+ '\tand New Status = ' +NewStateValue+ '\nAccountId = ' +AccountId+ '\tand Region = ' +Region
      
    #calling SNS message publish function to publish notification to email protocol 
    publishMessageToSNSTopic(SnsMessage,AlarmName,StateChangeTime)
    
def publishMessageToSNSTopic(SnsMessage,AlarmName,StateChangeTime):
    sns = boto3.client('sns')
    Result = 'Production Skydrm CloudWatch: '+AlarmName+ '-' +StateChangeTime
    #Result = 'Production Skydrm CloudWatch: srvOps_skydrm_S3BucketPolicyChangeMetric-2020-07-06T04:23:52.527+0000'
    print(Result)
    response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:512169772597:SKYDRM-DEVSECOPS',
        Subject=Result,
        Message= SnsMessage
    )
    print(response) 

