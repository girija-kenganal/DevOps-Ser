import json,boto3,sys ,datetime ,time
from botocore.vendored import requests
import pprint
import smtplib
import re

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from botocore.exceptions import ClientError


def lambda_handler(event, context):
    # TODO implement
    #print(event['body'])
    
    # Parse string to json
    y = json.loads(event['body'])
    
    
    

    
    toEmailList = y["toListArray"]
    emailBody = y["emailBody"]
    emailSubject = y["emailSubject"]
    
    # Create message container - the correct MIME type is multipart/alternative.
    msg = MIMEMultipart('alternative')
    fromEmail =  "no-reply@weir.skydrm.com"
    msg['Subject'] =  emailSubject
    msg['From'] = fromEmail

    part1 = MIMEText(emailBody, 'html')
    
    # Convert string to array
    toEmailList=toEmailList.split(',')
    
    print(toEmailList)
    print(fromEmail)
    success = 'n'
    
    for email in toEmailList:
        
        print("emailed : " + email)
        
        try:
            msg.attach(part1)
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login("admin@skydrm.com", "tgfslcylugtlgtjk")
            server.sendmail(fromEmail, email, msg.as_string())
            server.quit()
            print("Email sent")
            
            success ='y'
            
        except smtplib.SMTPException as e:
            print(str(e))
            
            success ='n'

    if success == 'y' :
        return {"statusCode": 200,"body": json.dumps("Success"),"isBase64Encoded":"false","headers": { "Access-Control-Allow-Origin" : "*", "Access-Control-Allow-Credentials" : "true" } }
    else:
        return {"statusCode": 500,"body": json.dumps("Error"),"isBase64Encoded":"false","headers": { "Access-Control-Allow-Origin" : "*", "Access-Control-Allow-Credentials" : "true" } }
            
