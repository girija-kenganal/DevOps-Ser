import boto3
from datetime import datetime
from pytz import timezone
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
        
   
    awsAccounts=['512169772597']
    
    for accountNumber in awsAccounts:
        try:
      
            ec2_client = boto3.client('ec2')
              
            
            
            #regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            regions = ['us-west-2','us-east-1']
            print(regions)
            
            msgString=''
            
            for region in regions:
                print(region)
                clientEC2 = boto3.resource('ec2', region_name=region)
            
                snsClient=boto3.client('sns')
                
                instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
                instanceList = []
                
                for instance in instances:
                    instanceList.append(instance.id)
                    instance = clientEC2.Instance(instance.id)
                    print(instance)
                    print(instance.id)
                
                    instance_tags = instance.tags
                    tagDict = dict()
                
                    
                    if instance.id == 'i-0346b224bed512cc0' or instance.id == 'i-02569d02fa6546c3c' or instance.id == 'i-031a8affeba203b17':
                        print(instance.id)
                        if instance_tags:
                    
                            for tag in instance_tags:
                                tagDict[tag['Key']] = tag['Value']
                    
                                try:
                                    
                                    # dir(instance)
                        
                                    if 'sgdc' in tagDict.values():
                                        tzone = timezone('Asia/Singapore')
                                        sa_time = datetime.now(tzone)
                                        currTime = int(sa_time.strftime('%H'))
                            
                                        print("TTL Shutdown Time %s %s" % (tagDict.get('TTL Shutdown Time'), sa_time.strftime('%a')))
                                        print("Current Time -  %s" % str(sa_time))
                                         
                                        if tagDict.get('TTL Shutdown Time') and tagDict.get('TTL Shutdown Time') != 'none' and int(tagDict.get('TTL Shutdown Time')) == currTime and int(tagDict.get('TTL Shutdown Time')) != 24:
                                            clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                            print("Shutting down EC2 -  %s" % str(instance.id))
                                            msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                            
                                    if 'smdc' in tagDict.values():
                                        tzone = timezone('America/Los_Angeles')
                                        sa_time = datetime.now(tzone)
                                        currTime = int(sa_time.strftime('%H'))
                                        
                                        print("TTL Start Time %s %s" % (tagDict.get('TTL Start Time'), sa_time.strftime('%a')))
                                        print("Current Time -  %s" % str(sa_time))
                            
                                        if tagDict.get('TTL Start Time') and tagDict.get('TTL Start Time') != 'none' and int(tagDict.get('TTL Start Time')) == currTime:
                                            clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                            print("Shutting down EC2 -  %s" % str(instance.id))
                                            msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                            
                                        
                                except ClientError as e:
                                       print(e)
                            

            if not msgString=='':
                print(msgString)

            

                            
        except ClientError as e:
            print(e)         
                
    return "success"